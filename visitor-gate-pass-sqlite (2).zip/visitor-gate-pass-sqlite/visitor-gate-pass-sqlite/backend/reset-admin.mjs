﻿import sqlite3 from "sqlite3";
import { open } from "sqlite";
import bcrypt from "bcryptjs";

const db = await open({ filename: "vgp.db", driver: sqlite3.Database });
const hash = bcrypt.hashSync("admin123", 10);

// replace existing admin (if any) and insert fresh one
await db.run("DELETE FROM VGP_USERS WHERE email = ?", "admin@example.com");
await db.run(
  "INSERT INTO VGP_USERS (email, password_hash, role) VALUES (?, ?, 'ADMIN')",
  "admin@example.com", hash
);

console.log("✅ Admin reset: admin@example.com / admin123");
process.exit(0);
