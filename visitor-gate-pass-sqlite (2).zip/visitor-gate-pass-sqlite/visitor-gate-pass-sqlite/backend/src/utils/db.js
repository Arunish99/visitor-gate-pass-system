import sqlite3 from "sqlite3";
import { open } from "sqlite";
import path from "path";
import fs from "fs";

const DB_FILE = process.env.DB_FILE || "./vgp.db";
let db;

export async function getDb() {
  if (!db) {
    db = await open({
      filename: DB_FILE,
      driver: sqlite3.Database
    });
  }
  return db;
}

export async function ensureDb() {
  const db = await getDb();
  await db.exec(`
    CREATE TABLE IF NOT EXISTS VGP_USERS (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT DEFAULT 'USER' CHECK (role IN ('USER','ADMIN')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS VGP_PASSES (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      requester_id INTEGER NOT NULL,
      visitor_name TEXT NOT NULL,
      visitor_phone TEXT,
      purpose TEXT,
      visit_date TEXT NOT NULL,
      status TEXT DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED','CHECKED_IN','CHECKED_OUT')),
      decided_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (requester_id) REFERENCES VGP_USERS(id)
    );
  `);
  // seed admin if not present
  const row = await db.get("SELECT COUNT(*) as c FROM VGP_USERS WHERE email = ?", "admin@example.com");
  if ((row?.c || 0) === 0) {
    await db.run(
      "INSERT INTO VGP_USERS (email, password_hash, role) VALUES (?,?,?)",
      "admin@example.com",
      "$2a$10$yALp4a0r2g0rX3kFhW7lYO0y9H0qjR4fCq1FZ1v5Gm9qv0o7o1m0G",
      "ADMIN"
    );
  }
}