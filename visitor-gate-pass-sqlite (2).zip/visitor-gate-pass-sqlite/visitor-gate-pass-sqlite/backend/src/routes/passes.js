import express from "express";
import { requireAuth } from "../middleware/auth.js";
import { getDb } from "../utils/db.js";

const router = express.Router();

router.post("/request", requireAuth, async (req, res) => {
  const { visitor_name, visitor_phone, purpose, visit_date } = req.body;
  if (!visitor_name || !visit_date) return res.status(400).json({ error: "Missing required fields" });
  try {
    const db = await getDb();
    const r = await db.run(
      `INSERT INTO VGP_PASSES (requester_id, visitor_name, visitor_phone, purpose, visit_date, status)
       VALUES (?,?,?,?,?, 'PENDING')`,
      req.user.uid, visitor_name, visitor_phone || "", purpose || "", visit_date
    );
    res.json({ id: r.lastID, status: "PENDING" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Could not create pass" });
  }
});

router.get("/mine", requireAuth, async (req, res) => {
  try {
    const db = await getDb();
    const rows = await db.all(
      `SELECT id, visitor_name, purpose, visit_date, status, created_at
       FROM VGP_PASSES WHERE requester_id = ? ORDER BY datetime(created_at) DESC`,
      req.user.uid
    );
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Could not fetch passes" });
  }
});

router.post("/:id/decision", requireAuth, async (req, res) => {
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Forbidden" });
  const { id } = req.params;
  const { decision } = req.body;
  if (!["APPROVED","REJECTED"].includes(decision)) return res.status(400).json({ error: "Bad decision" });
  try {
    const db = await getDb();
    await db.run(`UPDATE VGP_PASSES SET status = ?, decided_at = CURRENT_TIMESTAMP WHERE id = ?`, decision, id);
    res.json({ id, status: decision });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Decision failed" });
  }
});

export default router;