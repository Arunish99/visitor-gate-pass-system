import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import authRoutes from "./src/routes/auth.js";
import passRoutes from "./src/routes/passes.js";
import { ensureDb } from "./src/utils/db.js";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

app.get("/", (_req, res) => res.json({ status: "ok", service: "vgp-api-sqlite" }));

app.use("/api/auth", authRoutes);
app.use("/api/passes", passRoutes);

const PORT = process.env.PORT || 4000;

ensureDb().then(() => {
  app.listen(PORT, () => console.log(`VGP API (SQLite) http://localhost:${PORT}`));
}).catch(e => {
  console.error("DB init failed", e);
  process.exit(1);
});