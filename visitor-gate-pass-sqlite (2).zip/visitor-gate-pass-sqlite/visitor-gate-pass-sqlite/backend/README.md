# VGP API (SQLite Edition)

No Oracle needed. Uses a local SQLite file `vgp.db`.

## Run
```bash
cd backend
cp .env.example .env   # optional; defaults are fine
npm install
npm run dev
```

API: http://localhost:4000
Seed login: admin@example.com / admin123