import React, { useEffect, useState } from "react";
import Login from "./Login.jsx";
import RequestPass from "./RequestPass.jsx";
import MyPasses from "./MyPasses.jsx";
import Admin from "./Admin.jsx";

export default function App() {
  const [token, setToken] = useState(localStorage.getItem("token"));
  const [role, setRole] = useState(localStorage.getItem("role"));

  useEffect(() => {
    if (token) localStorage.setItem("token", token); else localStorage.removeItem("token");
    if (role) localStorage.setItem("role", role); else localStorage.removeItem("role");
    const onHash = () => setHash(window.location.hash);
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, [token, role]);

  const [hash, setHash] = useState(window.location.hash || "#request");
  if (!token) return <Login onLogin={(t, r) => { setToken(t); setRole(r); }} />;

  return (
    <div style={{ maxWidth: 720, margin: "20px auto", fontFamily: "system-ui, sans-serif" }}>
      <h1>Visitor Gate Pass (SQLite)</h1>
      <nav style={{ display: "flex", gap: 12, marginBottom: 20 }}>
        <button onClick={() => window.location.hash = "#request"}>Request Pass</button>
        <button onClick={() => window.location.hash = "#mine"}>My Passes</button>
        {role === "ADMIN" && <button onClick={() => window.location.hash = "#admin"}>Admin</button>}
        <button onClick={() => { setToken(null); setRole(null); }}>Logout</button>
      </nav>
      {hash === "#mine" ? <MyPasses token={token} /> :
       hash === "#admin" ? <Admin token={token} /> :
       <RequestPass token={token} />}
    </div>
  );
}