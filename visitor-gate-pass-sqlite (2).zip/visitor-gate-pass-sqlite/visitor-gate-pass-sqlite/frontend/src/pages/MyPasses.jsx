import React, { useEffect, useState } from "react";
export default function MyPasses({ token }) {
  const [rows, setRows] = useState([]);
  useEffect(() => {
    (async () => {
      const r = await fetch("http://localhost:4000/api/passes/mine", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await r.json();
      if (r.ok) setRows(data);
    })();
  }, [token]);
  return (
    <div>
      <h3>My Passes</h3>
      <ul>
        {rows.map(r => (
          <li key={r.id}>#{r.id} • {r.visitor_name} • {r.visit_date} • {r.status}</li>
        ))}
      </ul>
    </div>
  );
}