import React, { useState } from "react";
export default function RequestPass({ token }) {
  const [form, setForm] = useState({ visitor_name: "", visitor_phone: "", purpose: "", visit_date: "" });
  const [msg, setMsg] = useState("");
  async function submit(e) {
    e.preventDefault();
    setMsg("");
    const r = await fetch("http://localhost:4000/api/passes/request", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify(form)
    });
    const data = await r.json();
    if (!r.ok) return setMsg(data.error || "Failed");
    setMsg(`Created pass #${data.id} (${data.status})`);
    setForm({ visitor_name: "", visitor_phone: "", purpose: "", visit_date: "" });
  }
  return (
    <form onSubmit={submit} style={{ display: "grid", gap: 10 }}>
      <input placeholder="Visitor name" value={form.visitor_name} onChange={e => setForm({ ...form, visitor_name: e.target.value })} required />
      <input placeholder="Visitor phone" value={form.visitor_phone} onChange={e => setForm({ ...form, visitor_phone: e.target.value })} />
      <input placeholder="Purpose" value={form.purpose} onChange={e => setForm({ ...form, purpose: e.target.value })} />
      <input type="date" value={form.visit_date} onChange={e => setForm({ ...form, visit_date: e.target.value })} required />
      <button type="submit">Request Pass</button>
      {msg && <p>{msg}</p>}
    </form>
  );
}