import React, { useEffect, useState } from "react";
export default function Admin({ token }) {
  const [rows, setRows] = useState([]);
  async function load() {
    const r = await fetch("http://localhost:4000/api/passes/mine", {
      headers: { "Authorization": `Bearer ${token}` }
    });
    const data = await r.json();
    if (r.ok) setRows(data);
  }
  useEffect(() => { load(); }, []);
  async function decide(id, decision) {
    const r = await fetch(`http://localhost:4000/api/passes/${id}/decision`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify({ decision })
    });
    if (r.ok) load();
  }
  return (
    <div>
      <h3>Admin (demo)</h3>
      <ul>
        {rows.map(r => (
          <li key={r.id}>
            #{r.id} • {r.visitor_name} • {r.visit_date} • {r.status}
            <button onClick={() => decide(r.id, "APPROVED")} style={{ marginLeft: 8 }}>Approve</button>
            <button onClick={() => decide(r.id, "REJECTED")} style={{ marginLeft: 8 }}>Reject</button>
          </li>
        ))}
      </ul>
    </div>
  );
}