# VGP Web (React + Vite)

```bash
cd frontend
npm install
npm run dev
# open http://localhost:5173
```
API base is http://localhost:4000