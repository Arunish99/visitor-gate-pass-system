
# Visitor Gate Pass — SQLite Edition (Easy Setup)

**No Oracle required.** Local SQLite DB file, Node.js API, React frontend.

## Quick start
1) Backend
```
cd backend
cp .env.example .env   # optional
npm install
npm run dev
```
2) Frontend
```
cd ../frontend
npm install
npm run dev
```
Open http://localhost:5173

**Login:** admin@example.com / admin123
